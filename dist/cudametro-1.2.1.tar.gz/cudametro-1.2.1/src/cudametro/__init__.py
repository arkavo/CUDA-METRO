__version__ = '1.2.1'

import sys
#import montecarlo as montecarlo
from .construct import MonteCarlo
from .construct import Analyze