__version__ = '1.2.3'

import sys
#import montecarlo as montecarlo
from .construct import MonteCarlo
from .construct import Analyze